<template>
  <div id="app">
    <h1>Welcome to Stock Tracker!</h1>
    <router-view/>
  </div>
</template>

<style>
h1 {
  text-align: center;
}
</style>
