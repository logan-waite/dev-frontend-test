<template>
  <div>TODO: Add content</div>
</template>

<script>
export default {
  name: "History"
}
</script>

<style scoped>

</style>
